package it.itsvil.employee2.repository;

import it.itsvil.employee2.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeDao extends JpaRepository<Employee, Long> {

    @Query(value = "SELECT * FROM employee\n" +
            "WHERE employee.username = :username AND employee.password = :password", nativeQuery = true)
    List<Employee> findByAnagrafica(@Param("username") String _username, @Param("password") String _password);

    @Query(value ="SELECT * FROM employee WHERE employee.cognome_employee LIKE  :string% ",  nativeQuery = true)
    List<Employee> getByCognome (@Param("string") String s);


}
