package it.itsvil.employee2.dto.response;

import lombok.Data;

@Data
public class LoginResponseDto {
    private String t_username;
    private String t_password;
}
