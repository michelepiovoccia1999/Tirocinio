package it.itsvil.employee2.dto.request;
import lombok.Data;
@Data
public class LoginRequestDto {
    private String t_username;
    private String t_password;
}
