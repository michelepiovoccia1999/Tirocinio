package it.itsvil.employee2.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.cglib.core.Local;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@Entity
@Table(name ="Employee")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name ="id_employee")
    private Long n_idEmployee;

    @Column(name="nomeEmployee")
    private String t_nomeEmployee;

    @Column(name="cognomeEmployee")
    private String t_cognomeEmployee;

    @Column(name= "dataNascita")
    private LocalDate d_dataNascita;

    @Column (name = "username")
    private String t_username;

    @Column (name = "password")
    private String t_password;

    public Employee(String nome, String cognome, LocalDate data, String username,String t_password ){
        this.t_nomeEmployee=nome;
        this.t_cognomeEmployee=cognome;
        this.d_dataNascita=data;
        this.t_username=username;
        this.t_password=t_password;
    }
}
