package it.itsvil.employee2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Employee2Application {

    public static void main(String[] args) {
        SpringApplication.run(Employee2Application.class, args);
    }

}
