package it.itsvil.employee2;

import it.itsvil.employee2.dto.request.EmployeeRequestInsertDto;
import it.itsvil.employee2.entity.Employee;
import it.itsvil.employee2.repository.EmployeeDao;
import it.itsvil.employee2.service.imp.EmployeeService;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@SpringBootTest
class Employee2ApplicationTest {

    @Autowired
    private EmployeeService employeeService;

    @MockBean
    private EmployeeDao employeeDao;

    @Test
    public void getAllEmployeeTest(){
        when(employeeDao.findAll()).thenReturn(Stream
                .of(new Employee(
                        "nome", "cognome" , LocalDate.of(1999,12,12), "username", "password"
                )).collect(Collectors.toList()));
        assertEquals(1,employeeService.getAllEmployee().size() );
    }

    @Test
    public void addEmployeeTest (){
        EmployeeService employeeServiceMock= mock(EmployeeService.class);
        EmployeeRequestInsertDto employeeRequestInsertDto= new EmployeeRequestInsertDto();
        Employee employee= new Employee();
        when (employeeServiceMock.addEmployee(employeeRequestInsertDto)).thenReturn(employee);
        Employee result = employeeServiceMock.addEmployee(employeeRequestInsertDto);
        verify(employeeServiceMock).addEmployee(employeeRequestInsertDto);
    }

    /*
    @Test
    public void getEmployeeBuIdTest(){
        EmployeeService employeeServiceMock = mock(EmployeeService.class);
        Long testId= 1L;
        Employee employeeTest = new Employee();
        employeeTest.setN_idEmployee(testId);
        when(employeeService.getEmployeeById(testId)).thenReturn(employeeTest);
        Employee employeeService = employeeServiceMock.getEmployeeById(testId);
        assertEquals(testId, employeeService.getN_idEmployee());
        verify(employeeServiceMock).getEmployeeById(testId);
    }
     */
}